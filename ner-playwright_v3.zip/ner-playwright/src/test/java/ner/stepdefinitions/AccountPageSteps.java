package ner.stepdefinitions;

import io.cucumber.java.en.Given;
import ner.factory.DriverFactory;
import ner.pages.AccountPage;

public class AccountPageSteps {

	AccountPage accountPage = new AccountPage(DriverFactory.getPage());

	@Given("User selects ID with type as {string}")
	public void selectIdAS(String userType) {
		accountPage.selectUserIdWithType("TYPE", userType);
	}

	@Given("User searches and selects user ID {string}")
	public void searchAndSelectUserID(String userId) {
		accountPage.searchAndSelectAccountTable("USER ID", userId);
	}

	@Given("User verifies account info page is displayed")
	public void account_info_page() {
		accountPage.verifyAccountInnfoPageLoaded();
	}

	@Given("User Updates Company info {string}, {string}, {string}, {string}, {string}, {string} and Personal Info {string}, {string}, {string}, {string}, {string}")
	public void account_company_and_personal_info_page(String add1, String add2, String zipCode, String City,
			String state, String country, String fName, String lName, String middleName, String primaryPhone,
			String secondaryPhone) throws InterruptedException {
		System.out.println("Filling Info: "+add1);
		System.out.println("Filling Info: "+add2);
		System.out.println("Filling Info: "+zipCode);
		System.out.println("Filling Info: "+City);
		System.out.println("Filling Info: "+state);
		System.out.println("Filling Info: "+country);
		accountPage.updateCompanyInformation(add1, add2, zipCode, City, state, country);
		accountPage.updatePersonalInformation(fName, lName, middleName, primaryPhone, secondaryPhone);
		accountPage.saveInfoButton();
	}
	

	@Given("User verify account updated modal displayed")
	public void account_updated_modal() {
		accountPage.verifyAccountUpdatedModalDisplayed();
	}

}
