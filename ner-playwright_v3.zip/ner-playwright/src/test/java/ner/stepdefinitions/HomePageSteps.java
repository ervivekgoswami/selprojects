package ner.stepdefinitions;

import org.junit.Assert;

import io.cucumber.java.en.Given;
import ner.factory.DriverFactory;
import ner.pages.HomePage;

public class HomePageSteps {

	HomePage homePage = new HomePage(DriverFactory.getPage());

	@Given("User verifies NER homepage is displayed")
	public void navigateToUrl() {
		Assert.assertTrue(homePage.verifyHomePage());
	}

}
