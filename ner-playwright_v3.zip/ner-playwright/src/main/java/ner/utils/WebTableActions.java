package ner.utils;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.playwright.Locator;

import ner.pages.LoginPage;

public class WebTableActions {

	public Locator webTableLocator;
	private static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

	public WebTableActions(Locator webTableLocator) {
		this.webTableLocator = webTableLocator;
	}

	public int getNoOfRows() {
		int rows = webTableLocator.locator("tr").count();
		return rows;
	}

	public int getNoOfColumns() {
		int cols = webTableLocator.locator("th").count();
		return cols;
	}

	public List<String> getTableHeaders() {
		List<String> headers = webTableLocator.locator("th").allInnerTexts();
		logger.info("Headers in Table: "+ headers);
		return headers;
	}

	public int findIndexOfValueInColumn(String valueToFind, int columnNo) {
		List<String> values = webTableLocator.locator("tr td:nth-child(" + (columnNo) + ")").allInnerTexts();
		System.out.println("Full Column Value: " + values);
		int valueIndex = values.indexOf(valueToFind);
		return valueIndex + 1;
	}

	public void clickFirstColumnWithIndex(int rowToClick) {
		System.out.println("The Link: "+ "tr:nth-child(" + (rowToClick) + ") td:nth-child(1)");
		Locator clickCell = webTableLocator.locator("tr:nth-child(" + (rowToClick) + ") td:nth-child(1)");
		System.out.println("Clicking on First Cells");
		clickCell.click();
	}

}
