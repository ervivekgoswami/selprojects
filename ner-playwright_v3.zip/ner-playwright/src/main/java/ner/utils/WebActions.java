package ner.utils;

import com.microsoft.playwright.Locator;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.File;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Properties;

public class WebActions {
	
	
	public List<String> getAllInnertext(Locator locator){
		List<String> innertext = locator.allInnerTexts();
		return innertext;
	}
	

    
}