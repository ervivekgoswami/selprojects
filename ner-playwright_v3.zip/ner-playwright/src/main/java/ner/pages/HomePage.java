package ner.pages;


import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import ner.utils.WebUtils;

public class HomePage {
	
	private Page page;
    private final Locator HOMEPAGE_MENU;
    
    public HomePage(Page page) {
        this.page = page;
        this.HOMEPAGE_MENU = page.locator("#menu");
    }
    
    public boolean verifyHomePage() {
    	boolean isDisplayed = WebUtils.waitUntilElementDisplayed(HOMEPAGE_MENU, 10);
    	System.out.println("ID id displayed: "+ isDisplayed);
    	return isDisplayed;
    	
    }

}
