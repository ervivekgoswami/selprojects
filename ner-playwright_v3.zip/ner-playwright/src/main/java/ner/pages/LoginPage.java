package ner.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ner.utils.WebUtils;

public class LoginPage {
    private Page page;
    private final Locator USERNAME_EDITBOX;
    private final Locator PASSWORD_EDITBOX;
    private final Locator LOGIN_BUTTON;
    private final Locator BOOKS_SEARCH_BOX;
    
    private static final Logger logger = LoggerFactory.getLogger(LoginPage.class);

    public LoginPage(Page page) {
        this.page = page;
        this.USERNAME_EDITBOX = page.locator("#UserName");
        this.PASSWORD_EDITBOX = page.locator("#Password");
        this.LOGIN_BUTTON = page.locator("input[class='button button-sm']");
        this.BOOKS_SEARCH_BOX = page.getByPlaceholder("Type to search");
    }

    public void navigateToUrl() {
    	String navigaetTo = WebUtils.getProperty("app_url");
        this.page.navigate(navigaetTo);
        logger.info("Opened Application: "+ navigaetTo);
        logger.debug("Opened Application: "+ navigaetTo);
        logger.error("Opened Application: "+ navigaetTo);
    }

    public void enterUsername(String username) {
        USERNAME_EDITBOX.fill(WebUtils.getProperty(username));
    }

    public void enterPassword(String password) {
        PASSWORD_EDITBOX.fill(WebUtils.decrypt(password));
    }

    public void clickLogin() {
        LOGIN_BUTTON.click();
       
    }

    public void clickOnIcon(String iconName) {
        this.page.getByText(iconName, new Page.GetByTextOptions().setExact(true)).click();  // Clicks on the Exact text
    }

    public boolean verifyProfilePage() {
        return WebUtils.waitUntilElementDisplayed(this.BOOKS_SEARCH_BOX, 60);
    }
}
