package ner.pages;

import com.aventstack.extentreports.util.Assert;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import ner.utils.WebActions;
import ner.utils.WebTableActions;
import ner.utils.WebUtils;

public class AccountPage {

	private Page page;
	private final Locator accountTableBody;
	private final Locator accountTableHeader;
	private final Locator accountInfoPage;
	private final Locator companyInfoCompanyName;
	private final Locator companyInfoAdd1;
	private final Locator companyInfoAdd2;
	private final Locator companyInfoZip;
	private final Locator companyInfoCity;
	private final Locator companyInfoState;
	public final Locator companyInfoCountry;

	private final Locator personalInfoFname;
	private final Locator personalInfoLname;
	private final Locator personalInfoMname;
	private final Locator personalInfoJobTitle;
	private final Locator personalInfoPrimaryPhone;
	public final Locator personalInfoSecPhone;
	public final Locator saveInfoButton;
	public final Locator saveAccountModalOk_button;

	public AccountPage(Page page) {
		this.page = page;
		this.accountTableBody = page.locator("table[class='k-grid-table'] tbody");
		this.accountTableHeader = page.locator("div[class='k-grid-header-wrap'] table thead");
		this.accountInfoPage = page.locator("#acountInfo");
		this.companyInfoCompanyName = page.locator("[id='compname'] input");
		this.companyInfoAdd1 = page.locator("input#addr1");
		this.companyInfoAdd2 = page.locator("input#addr2");
		this.companyInfoZip = page.locator("input#zip");
		this.companyInfoCity = page.locator("input#city");
		this.companyInfoState = page.locator("#state");
		this.companyInfoCountry = page.getByLabel("#country");
		this.personalInfoFname = page.locator("input#firstName");
		this.personalInfoLname = page.locator("input#lastName");
		this.personalInfoMname = page.locator("input#middleName");
		this.personalInfoJobTitle = page.locator("input#PrimaryPhone");
		this.personalInfoPrimaryPhone = page.locator("input#PrimaryPhone");
		this.personalInfoSecPhone = page.locator("input#SecondaryPhone");;
		this.saveInfoButton = page.locator("#btnSaveAccount");
		this.saveAccountModalOk_button = page.locator("//div[@class='modal-header' and text()=' Save Accounts ']//parent::div//input");

	}

	public void selectUserIdWithType(String header, String userType) {
		WebUtils.waitUntilElementDisplayed(this.accountTableBody, 20);
		WebTableActions tableHeaderActions = new WebTableActions(accountTableHeader);
		WebTableActions tableBodyAction = new WebTableActions(accountTableBody);
		int columnType = tableHeaderActions.getTableHeaders().indexOf(header) + 1;
		int ownerAdmin = tableBodyAction.findIndexOfValueInColumn(userType, columnType);
		tableBodyAction.clickFirstColumnWithIndex(ownerAdmin);
	}

	public void searchAndSelectAccountTable(String searchInHeader, String textToSearch) {
		WebUtils.waitUntilElementDisplayed(accountTableHeader, 20);
		WebTableActions tableActions = new WebTableActions(accountTableHeader);
		WebTableActions tableBodyAction = new WebTableActions(accountTableBody);
		int columnNo = tableActions.getTableHeaders().indexOf(searchInHeader) + 1;
		Locator searchTextCell = accountTableHeader
				.locator("tr:nth-child(2) td:nth-child(" + columnNo + ") input[kendofilterinput]");
		searchTextCell.fill(textToSearch);
		tableBodyAction.clickFirstColumnWithIndex(1);
	}

	public void verifyAccountInnfoPageLoaded() {
		WebUtils.waitUntilElementDisplayed(accountInfoPage, 20);
		boolean isLoaded = accountInfoPage.isVisible();
		System.out.println("Page loaded: " + isLoaded);
	}

	public void updateCompanyInformation(String add1, String add2, String zipCode, String City, String state,
			String country) throws InterruptedException {
		WebUtils.waitUntilElementDisplayed(companyInfoCompanyName, 20);
		companyInfoAdd1.fill(add1);
		companyInfoAdd2.fill(add2);
		companyInfoZip.fill(zipCode);
		companyInfoCity.fill(City);
		boolean isLoaded = companyInfoState.isVisible();
		System.out.println("companyInfoState loaded: " + isLoaded);
//		companyInfoState.selectOption(state);
//		companyInfoCountry.selectOption(country);
	}
	
	public void updatePersonalInformation(String fName, String lName, String middleName, String primaryPhone,
			String secondaryPhone) throws InterruptedException {
		WebUtils.waitUntilElementDisplayed(companyInfoCompanyName, 20);
		personalInfoFname.fill(fName);
		personalInfoLname.fill(lName);
		personalInfoMname.fill(middleName);
		personalInfoPrimaryPhone.fill(primaryPhone);
		personalInfoSecPhone.fill(secondaryPhone);
	}
	
	public void saveInfoButton() throws InterruptedException {
		saveInfoButton.click();
	}
	
	public boolean verifyAccountUpdatedModalDisplayed() {
		WebUtils.waitUntilElementDisplayed(saveAccountModalOk_button, 10);
		boolean modal_save_accounts = saveAccountModalOk_button.isVisible();
		System.out.println("The Modal Displayed: "+ modal_save_accounts);
		saveAccountModalOk_button.click();
		return modal_save_accounts;
		
	}

}
