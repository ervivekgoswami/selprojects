package com.superLibra.APIStepDefinitions;

import com.superLibra.APIPayloads.PayLoads;
import com.superLibra.APIResources.APIResources;
import com.superLibra.APIResources.APIUtilities;
import com.superLibra.APIResources.GenericKeywords;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;


import java.io.IOException;

import org.testng.Assert;

import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class DemoAPIStepDefinitions extends APIUtilities {

	RequestSpecification res;
	ResponseSpecification resspec;
	Response response;
	GenericKeywords genKeys;

	@When("user calls {string} with {string} http request")
	public void user_calls_with_http_request(String resource, String method) throws IOException {
		APIResources resourceAPI = APIResources.valueOf(resource);
		String resurceVal = genKeys.getTestData().get("EndPoint");
		System.out.println("Enum resource is: " + resurceVal);
		res = given().spec(requestSpecification()).body(PayLoads.libraIntegrationAccountBody());

		resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

		if (method.equalsIgnoreCase("POST"))
			response = res.when().post(resourceAPI.getResource());
		else if (method.equalsIgnoreCase("GET"))
			response = res.when().get(resourceAPI.getResource());
	}

	@Then("the API call got success with status code {int}")
	public void the_api_call_got_success_with_status_code(Integer int1) {
		Assert.assertEquals(response.getStatusCode(),200);
	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String keyValue, String Expectedvalue) {
		System.out.println("The Response of body: "+response.asString());
		Assert.assertEquals(getJsonPath(response,keyValue),Expectedvalue);
	}

}
