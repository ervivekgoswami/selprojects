package com.superLibra.APIPayloads;

public class PayLoads {
	
	
	public static String libraIntegrationAccountBody() {
		
		String body = "{\r\n"
				+ "    \"AccountExists\":{ \"UniversalAccountId\" :\"12345\"},\r\n"
				+ "    \"UserName\":\"LibraAPI\",\r\n"
				+ "    \"AuthToken\":\"\"}";
		return body;
		
	}
	
public static String libraIntegrationVehicleBody() {
		
		String body = "{\r\n"
				+ "    \"Vehicle\" : {\"UniversalAccountId\" : \"1234\", \"VIN\" : \"1234\" },\r\n"
				+ "    \"UserName\":\"LibraAPI\",\r\n"
				+ "    \"AuthToken\":\"\"}";
		return body;
		
	}

public static String libraIntegrationSensorBody() {
	
	String body = "{\r\n"
			+ "    \"GetSensors\" : {\"UniversalAccountId\" : \"1234\" },\r\n"
			+ "    \"UserName\":\"LibraAPI\",\r\n"
			+ "    \"AuthToken\":\"\"}";
	return body;
	
}

}
