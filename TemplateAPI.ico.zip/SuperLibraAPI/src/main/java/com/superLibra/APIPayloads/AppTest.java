package com.superLibra.APIPayloads;

import static io.restassured.RestAssured.given;

import java.io.IOException;

import com.superLibra.APIResources.APIResources;
import com.superLibra.APIResources.APIUtilities;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

/**
 * Unit test for simple App.
 */ 
public class AppTest extends APIUtilities
{
//	public static RequestSpecification req;
//	
//	public RequestSpecification specBuilder() {
//		req = new RequestSpecBuilder().setBaseUri("https://libra.api.stage.us.fleetmatics.com")
//    			.setContentType(ContentType.JSON).build();
//		return req;
//		
//	}
	
	RequestSpecification res;
	ResponseSpecification resspec;
	Response response;

    public void LibraIntegrationAccountPost() throws IOException
    {
    	
    	
    	String resource = "libraIntegrationAccount";
//    	String postResponse = given().spec(specBuilder()).body(payLoads.libraIntegrationAccountBody()).when().post(resource).
//    	then().assertThat().statusCode(200).extract().response().asString();
    	
    	APIResources resourceAPI=APIResources.valueOf(resource);
		System.out.println("Enum resource is: "+resourceAPI.getResource());
		res=given().spec(requestSpecification()).body(PayLoads.libraIntegrationAccountBody());
		
		resspec =new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
//		if(method.equalsIgnoreCase("POST"))
		 response =res.when().post(resourceAPI.getResource());
//		else if(method.equalsIgnoreCase("GET"))
//			 response =res.when().get(resourceAPI.getResource());
    	System.out.println("The Response of Account post request is: "+response.getStatusCode());
    	
    }
    
//    @Test
    public void LibraIntegrationVehiclePost()
    {
//    	String resource = "libraintegrationservice.svc/vehicle/getbyvin";
//    	String postResponse = given().spec(specBuilder()).body(payLoads.libraIntegrationVehicleBody()).when().post(resource).
//    	then().assertThat().statusCode(200).extract().response().asString();
//    	System.out.println("The Response of Vehicle post request is: "+postResponse);
    	
    }
    
//    @Test
    public void LibraIntegrationSensorPost()
    {
//    	String resource = "libraintegrationservice.svc/sensors/get";
//    	String postResponse = given().spec(specBuilder()).body(payLoads.libraIntegrationSensorBody()).when().post(resource).
//    	then().assertThat().statusCode(200).extract().response().asString();
//    	System.out.println("The Response of Sensor post request is: "+postResponse);
    	
    }
}
