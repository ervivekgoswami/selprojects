package com.superLibra.APIResources;

public enum APIResources {
	
	libraIntegrationAccount("/libraintegrationservice.svc/account/exists"),
	LibraIntegrationVehicle("/libraintegrationservice.svc/vehicle/getbyvin"),
	LibraIntegrationSensor("/ibraintegrationservice.svc/sensors/get");
	
	private String resource;
	
	
	APIResources(String resource)
	{
		this.resource=resource;
	}
	
	public String getResource()
	{
		return resource;
	}

}
