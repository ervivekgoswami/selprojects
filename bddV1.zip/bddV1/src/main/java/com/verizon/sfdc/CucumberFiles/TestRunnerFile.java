package com.verizon.sfdc.CucumberFiles;

import java.awt.Desktop;
import java.io.File;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.verizon.sfdc.excel.ExcelReader;
import com.verizon.sfdc.test.executor.TestExecutionEngine;
import com.verizon.sfdc.test.report.ReportListener;

import io.cucumber.testng.CucumberOptions;


/**
 * This class is the execution engine
 * @author Nataraaj
 */
@CucumberOptions(
		features={"src/main/java/com/verizon/sfdc/CucumberFiles/featureFiles"},
		glue={"com.verizon.sfdc.CucumberFiles"}
		)
public class TestRunnerFile extends TestExecutionEngine{

	@Parameters("ExecutionName")
	@BeforeTest
	public void executionType(String executionType){
		if(executionType.equals("ReRunExecution"))
			rerun=true;
	}

	/**
	 * Function to call before execution of each scenario
	 *//*
	@BeforeMethod
	public void openBrowser(){
		super.openBrowser();
	}*/

	/**
	 * Function to call after execution of each scenario
	 */
	@AfterMethod
	public void closeBroswer(){
		try {
			getDriver().quit();
		} catch (Exception e) {
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		}
	}

	/**
	 *  Function to call after execution of all test
	 */
	@AfterSuite
	public void closeResources(){
		try {
			ExcelReader.book.close();
			System.out.println();
			System.out.println();
			System.out.println("*********************************");
			System.out.println("Report");
			System.out.println(".");
			System.out.println(ReportListener.reportPath+"/PrimaryExecutionReport.html");
			System.out.println(".");
			System.out.println("*********************************");
			
			if(suiteProp.getProperty("openReport").equalsIgnoreCase("Yes")) {
				String filePath= ReportListener.reportPath+"/PrimaryExecutionReport.html";
				File reportFile = new File(filePath);
				Desktop.getDesktop().browse(reportFile.toURI());
			}
		
		} catch (Exception e) {
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		}
	}
}