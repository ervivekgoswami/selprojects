package com.verizon.sfdc.pagesObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Hashtable;

public class HomePageObjects {
    WebDriver driver;
    Hashtable<String, String> dataTable;

    public By SignInOktaBtn = By.xpath("//input[@value='Sign in with Okta']");


}
