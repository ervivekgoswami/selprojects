package com.verizon.sfdc.utils;

import java.io.IOException;
import java.io.InputStream;

public class CommonUtilFunctions {	
	
	/**
	 * This is to run a bat file to do following actions
	 * Delete chrome webdriver(s) in background
	 * Move a copy of report to project location
	 * delete extra created images files in report folder
	 * @author Nataraaj
	 */
	public void runBatFile(String fileLocation, String fileName){
		ProcessBuilder pb = new ProcessBuilder(fileLocation+"\\"+fileName+".bat");
		pb.redirectError();
		try {
			Process p = pb.start();
			try (InputStream inputStream = p.getInputStream()) {
				@SuppressWarnings("unused")
				int in = -1;
				while ((in = inputStream.read()) != -1) {}
			}
			p.waitFor();
		} catch (IOException | InterruptedException ex) {
			ex.printStackTrace();
		}		
	}

}
