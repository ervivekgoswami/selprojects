package com.verizon.sfdc.test.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.verizon.sfdc.commons.GenericKeywords;

public class ReportListener implements ITestListener {

	/**
	 * Initialization of property file location 
	 * @updated Nataraaj
	 */
	static{
		try {
			InputStream input = new FileInputStream("src/test/resources/application.properties");
			GenericKeywords.suiteProp.load(input);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static String reportPath=System.getProperty("user.dir")+"/reports/TestReport_" + new Date().toString().replace(":", "_").replace(" ", "_");
	public static ExtentReports extent ;
	public static ThreadLocal<ExtentTest> threadExtentTest = new ThreadLocal<ExtentTest>();
	public static ThreadLocal<String> threadTestCaseName = new ThreadLocal<>();
	public static String testSuiteName="";

	/**
	 * Function to get Testcase name of the current thread
	 * @return
	 */
	private String getTestCaseName(){
		return threadTestCaseName.get();
	}

	/**
	 * Function to get Testcase name of the current thread
	 * @return
	 */
	private ExtentTest getExtentTest(){
		return threadExtentTest.get();
	}

	@Override
	public void onTestSuccess(ITestResult result) {}

	@Override
	public void onTestFailure(ITestResult result) {}

	@Override
	public void onTestSkipped(ITestResult result) {
		try {
			String methodName=getTestCaseName();
			String logText="<b>"+"TEST CASE:- "+ methodName.toUpperCase()+ " SKIPPED"+"</b>";		
			Markup m=MarkupHelper.createLabel(logText, ExtentColor.WHITE);
			getExtentTest().skip(m);	
			List<String> failedScenario = FileUtils.readLines(new File(GenericKeywords.suiteProp.getProperty("failedScenarioRerunDetails")) , StandardCharsets.UTF_8);
			if(!failedScenario.contains(getTestCaseName()))
				failedScenario.add(getTestCaseName());
			GenericKeywords.threadDriver.get().quit();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}

	@Override
	public void onFinish(ITestContext context) {
		if(extent!=null)
			extent.flush();
	}

	@Override
	public void onTestStart(ITestResult result) {}

	@Override
	public void onStart(ITestContext context) {
		try {
		if(context.getName().contains("ReRunExecution")) {
			extent = ReportManager.createInstance(reportPath+"/FailedScenariosReRunReport.html");
		}
		else if(context.getName().equals("PrimaryExecution")) {
			extent = ReportManager.createInstance(reportPath+"/PrimaryExecutionReport.html");
		}
	} catch (IOException e) {

		e.printStackTrace();
	}
	}
}
