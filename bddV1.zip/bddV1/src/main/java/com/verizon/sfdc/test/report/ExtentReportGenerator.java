package com.verizon.sfdc.test.report;

import java.util.HashMap;

import com.aventstack.extentreports.ExtentTest;

import com.verizon.sfdc.commons.GenericKeywords;

import io.cucumber.testng.CucumberFeatureWrapper;


public class ExtentReportGenerator extends GenericKeywords {

	private static HashMap<String, ExtentTest> masterNodeObjectMap = new HashMap<>();
	static boolean flag=false;
	/**
	 * Creating Node for feature
	 * @param featureWrapper
	 * @author Nataraaj
	 * @param rerun 
	 */
	void featureNode(String featureName, boolean rerun) {
		if(!masterNodeObjectMap.containsKey(featureName)){
			ReportListener.testSuiteName = featureName;
			ExtentTest masterNodeObject;
			masterNodeObject = ReportListener.extent.createTest("Feature Name: "+featureName);
			masterNodeObjectMap.put(featureName, masterNodeObject);
		}
	}

	/**
	 * Function to create feature and scenario node in extent report
	 * @param featureWrapper
	 * @param currentScenarioDataPicker
	 * @author Nataraaj
	 * @param rerun 
	 */
	public void initiateReporter(CucumberFeatureWrapper featureWrapper,String currentScenarioDataPicker, boolean rerun ){
		if(rerun && !flag){
			masterNodeObjectMap.clear();
			flag = !flag;
		}
		String featureName= featureWrapper.toString().replace("\"", "");
		featureNode(featureName,rerun);
		scenarioNode(currentScenarioDataPicker,featureName,rerun);
	}

	/**
	 * Function to create Master node and sub node in extent report (for non-feature executions)
	 * @param MasterNode
	 * @param SubNode
	 * @author Nataraaj
	 */
	public void initiateReporter(String MasterNode ,String SubNode){
		featureNode(MasterNode,false);
		scenarioNode(SubNode, MasterNode,false);
	}

	/**
	 * Creating Node for Scenario
	 * @param scenarioName
	 * @param featureName
	 * @author Nataraaj
	 * @param rerun 
	 */
	void scenarioNode(String scenarioName, String featureName, boolean rerun) {
		ExtentTest testCase = masterNodeObjectMap.get(featureName).createNode("Scenario Name: " + scenarioName);
		threadExtentReporter.set(testCase);
		ReportListener.threadExtentTest.set(testCase);
		ReportListener.threadTestCaseName.set(scenarioName);
	}
}
