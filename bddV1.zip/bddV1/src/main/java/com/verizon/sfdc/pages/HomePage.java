package com.verizon.sfdc.pages;

import com.verizon.sfdc.commons.GenericKeywords;
import com.verizon.sfdc.test.executor.TestExecutionEngine;
import org.openqa.selenium.By;

import java.util.HashSet;
import java.util.Properties;

public class HomePage extends GenericKeywords {

    public void lauchbrowserAndlogin(){
        navigate(suiteProp.getProperty("appUrl"));
        click(objHomePgeObj.SignInOktaBtn);
        logInfo("PASS","Successfully logged into SL");
    }

}
