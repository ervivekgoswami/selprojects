package com.verizon.sfdc.CucumberFiles;

import com.verizon.sfdc.pages.HomePage;
import cucumber.api.PendingException;
import io.cucumber.java.en.Given;
import com.verizon.sfdc.commons.GenericKeywords;

import java.util.HashSet;
import java.util.Properties;


public class HomePage_SD extends GenericKeywords{

    public static Properties suiteProp = new Properties();
    protected static HashSet<String> failedScenario = new HashSet<>();
    protected static boolean rerun=false;

        @Given("^I am in login screen$")
        public void login() throws Exception {
            HomePage objHomepge = new HomePage();
            objHomepge.lauchbrowserAndlogin();

        }


}
