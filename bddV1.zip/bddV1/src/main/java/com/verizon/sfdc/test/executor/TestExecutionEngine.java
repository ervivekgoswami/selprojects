package com.verizon.sfdc.test.executor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.verizon.sfdc.commons.GenericKeywords;
import com.verizon.sfdc.excel.ExcelReader;
import com.verizon.sfdc.test.report.ExtentReportGenerator;

import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;

public class TestExecutionEngine extends GenericKeywords{
	
	private TestNGCucumberRunner testNGCucumberRunner;
	
	/**collection to add testdata for all executing scenarios*/
	static HashMap<String, ArrayList<HashMap<String, String>>> allExecutingScenariosTestData= new HashMap<>();

	/**collection to add scenario(s) names and used to fetch correct testdata from 'allExecutingScenariosTestData' HashMap*/
	HashMap<String, Integer> scenarioDetails = new HashMap<>();


	/**
	 * 	Function to create instance for 'TestNGCucumberRunner' class
	 * @author Nataraaj
	 */
	@BeforeClass(alwaysRun = true)
	public void setUpClass() {
		try{
			testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		}catch (Exception e) {
			e.printStackTrace();
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		} 
	}


	/**
	 * Function to pass testdata to step definition file,initialize reporter and run scenario(s) based on input from 'scenarios' Function
	 * @param pickleWrapper
	 * @param featureWrapper
	 * @author Nataraaj
	 */
	@Test(dataProvider = "scenarios")
	public void runScenario(PickleEventWrapper pickleWrapper, CucumberFeatureWrapper featureWrapper)  {
		try{
			//scenario name and testdata for executing scenario from the 'allExecutingScenariosTestData' collection
			String currentScenarioName = pickleWrapper.getPickleEvent().pickle.getName().trim();
			if(rerun)
				System.out.println("Rerun execution : "+currentScenarioName);
			else
				System.out.println("primary execution : "+currentScenarioName);
			
			if(scenarioDetails.containsKey(currentScenarioName)){
				scenarioDetails.put(currentScenarioName, scenarioDetails.get(currentScenarioName)+1);
			}else{
				scenarioDetails.put(currentScenarioName, 1);
			}
			
			  
			
			//Initializing the browser
			String[] nameOfTheResource = suiteProp.getProperty("admin_username_uat").split("@")[0].split("\\.");
			String name = "SL Automation Team: "+nameOfTheResource[0].toUpperCase()+" "+nameOfTheResource[1].toUpperCase()+" || Scenario: "+currentScenarioName;
			openBrowser(name);

			//Passing testdata to generic keywords
			threadTestData.set(allExecutingScenariosTestData.get(currentScenarioName).get((scenarioDetails.get(currentScenarioName))-1));
			
			//initiating reporter for executing scenario
			new ExtentReportGenerator().initiateReporter(featureWrapper,currentScenarioName,rerun);

			try{
				//Executing the scenario
				testNGCucumberRunner.runScenario(pickleWrapper.getPickleEvent());
			}catch (Throwable e) {
				e.printStackTrace();
				logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		} 
	}

	/**
	 *  Function(Dataprovider) to pass scenario(s) from execution scenarios list filtered
	 * @return Scenario
	 * @author Nataraaj
	 */
	@DataProvider(parallel = false)
	public Iterator<Object[]> scenarios() {
		ArrayList<Object[]> modifiedList = new ArrayList<>();
		try{
			if (testNGCucumberRunner == null) {
				return modifiedList.iterator();
			}
			modifiedList = filterTheFeature(testNGCucumberRunner.provideScenarios());
		}
		catch (Exception e) {
			e.printStackTrace();
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		} 
		return modifiedList.iterator();
	}

	/**
	 * Function to filter scenario and add to execution array based on data from Master Sheet
	 * @param data
	 * @return ArrayList of scenario(s) to execute
	 * @author Nataraaj
	 */
	private ArrayList<Object[]> filterTheFeature(Object[][] data) {
		ArrayList<Object[]> modifiedList = new ArrayList<>();
		HashMap<String, ArrayList<Object[]>> featureAndScenario =new HashMap<>();
		try{
			if(allExecutingScenariosTestData == null || allExecutingScenariosTestData.isEmpty()){
				System.exit(1);
			}else{
				ArrayList<String> scenarioList=null;
				if(rerun){
					scenarioList = new ArrayList<>(failedScenario);
					if(scenarioList.isEmpty() || scenarioList==null)
						System.exit(1);
				}else{
					scenarioList = new ArrayList<>(allExecutingScenariosTestData.keySet());
				}
				if(data != null){
					for ( String scenarioName : scenarioList) {
						scenarioName= scenarioName.trim();
						ArrayList<Object[]> tempObjectCollector = new ArrayList<>();
						String featureName="";
						for (int i = 0; i < data.length; i++) {
							featureName  = ((CucumberFeatureWrapper)data[i][1]).toString().trim().replace("\"", "");
							String scenarioNameFromFeatureFile = ((PickleEventWrapper)data[i][0]).toString().trim().replaceAll("\"", "");
							if(scenarioName.contains((scenarioNameFromFeatureFile))){
								if(rerun){
									tempObjectCollector.add(data[i]);
									if(featureAndScenario.containsKey(featureName))
										tempObjectCollector.addAll(featureAndScenario.get(featureName));
									featureAndScenario.put(featureName,tempObjectCollector);
								}else{
									for (int k = 0; k < allExecutingScenariosTestData.get(scenarioName).size(); k++) {
										tempObjectCollector.add(data[i]);
										System.out.println(featureAndScenario.toString()+" "+featureName+" "+featureAndScenario.containsKey(featureName));
										if(featureAndScenario.containsKey(featureName)) {
											tempObjectCollector.addAll(featureAndScenario.get(featureName));
										}
										featureAndScenario.put(featureName,tempObjectCollector);
									}
								}
								break;
							}
						}
					}
					for (String key : featureAndScenario.keySet())
						modifiedList.addAll(featureAndScenario.get(key));
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		} 
		return modifiedList;
	}

	/**
	 * Function to put all scenario in feature file to execution list
	 * @param data
	 * @return ArrayList of scenario(s) to execute
	 * @author Nataraaj
	 */
	/*private ArrayList<Object[]> getFeatureList(Object[][] data) {
		ArrayList<Object[]> modifiedList = new ArrayList<>();
		try{
			if(data != null){
				for (int i = 0; i < data.length; i++) {
					modifiedList.add(data[i]);
				}
			}
		}catch (Exception e) {
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		}
		return modifiedList;
	}*/

	/**
	 * Function to close resources opened before/while execution
	 * @author Nataraaj
	 */
	@AfterClass(alwaysRun = true)
	public void tearDownClass() {
		try{
			if (testNGCucumberRunner == null) {
				return;
			}
			testNGCucumberRunner.finish();
		}
		catch (Exception e) {
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		}
	}

	/**
	 * Function to fetch com.verizon.sfdc.CucumberFiles data from excel before com.verizon.sfdc.CucumberFiles begins
	 * @author Nataraaj
	 */

	@BeforeSuite
	public void testData(){
		try{
			allExecutingScenariosTestData = new ExcelReader(suiteProp.getProperty("dataSheet")).masterExecutionData("Master Sheet");
		}
		catch (Exception e) {
			logInfo("ERROR",  "Error while executing method " + getMethodName() +" in the class file "+getClassName()+ " with error: " + e.toString());
		}
	}

}